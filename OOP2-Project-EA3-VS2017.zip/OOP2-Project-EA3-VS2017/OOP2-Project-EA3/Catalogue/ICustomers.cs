﻿namespace OOP2_Project_EA3
{
    public interface ICustomers : ICatalogue<Customer>
    {
    }
}